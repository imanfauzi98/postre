package postre.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import postre.models.entities.Pelanggan;
import postre.services.PelangganService;

@RestController
@RequestMapping("/api/pelanggan")
public class PelangganController {
    
    @Autowired
    private PelangganService pelangganService;

    @PostMapping
    public Pelanggan create(@RequestBody Pelanggan pelanggan){
        return pelangganService.save(pelanggan);
    }

    @GetMapping
    public Iterable<Pelanggan> findAll(){
        return pelangganService.findAll();
    }

    @GetMapping("/{id}")
    public Pelanggan findOne(@PathVariable("id") Long id){
        return pelangganService.findOne(id);
    }

    @DeleteMapping("/{id}")
    public Pelanggan removeOne(@PathVariable("id") Long id){
        pelangganService.removeOne(id);
        return null;
    }

    @PutMapping
    public Pelanggan update(@RequestBody Pelanggan pelanggan){
        return pelangganService.save(pelanggan);
    }


}
