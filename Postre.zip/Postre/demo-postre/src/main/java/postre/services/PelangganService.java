package postre.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import postre.models.entities.Pelanggan;
import postre.models.repos.PelangganRepo;

@Service
@Transactional
public class PelangganService {
    
    @Autowired
    private PelangganRepo pelangganRepo;


    public Pelanggan save(Pelanggan pelanggan){
        return pelangganRepo.save(pelanggan);
    }

    public Pelanggan findOne(Long id){
        return pelangganRepo.findById(id).get();
    }

    public Iterable<Pelanggan> findAll(){
        return pelangganRepo.findAll();
    }

    public void removeOne(Long id){
        pelangganRepo.deleteById(id);
    }

    public List<Pelanggan> findByName(String name){
        return pelangganRepo.findByNameContains(name);
    }
}
